package ch.hsr.prog2.dijkstragvs;

import java.util.LinkedHashMap;
import java.util.logging.Logger;

import ch.hsr.prog2.dijkstragvs.AdjacencyListGraphGVS.MyGvsEdge;
import ch.hsr.prog2.dijkstragvs.AdjacencyListGraphGVS.MyGvsVertex;

@SuppressWarnings({"unchecked"})

public class LinkedHashMapGVS<K,V> extends LinkedHashMap<K,V> {
  
  private static final long serialVersionUID = 1L;
  
  protected GvsSupport gvsSupport;
  
  private static final Logger log = Logger.getLogger(LinkedHashMapGVS.class.getName());
  
  @Override
  public V put(K key, V value) {
    log.info(key+" -> "+value);
    V result = super.put(key, value);
    if (key instanceof MyGvsVertex && value instanceof Integer) {
      // this is the distances-map
      gvsSupport.updateVertex((MyGvsVertex)key, this);
    } else if (key instanceof MyGvsVertex && value instanceof MyGvsEdge) {
      // this is the parents-map
      gvsSupport.newParentEdge((MyGvsEdge)result, (MyGvsEdge)value);
    }
    return result;
  }

}
