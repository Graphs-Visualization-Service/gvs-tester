package ch.hsr.prog2.dijkstragvs;

import java.util.NoSuchElementException;
import java.util.logging.Logger;

import net.datastructures.Edge;
import net.datastructures.ElementIterator;
import net.datastructures.PositionList;

@SuppressWarnings({"unchecked"})
 
public class ElementIteratorGVS<E> extends ElementIterator<E> {
  
  GvsSupport gvsSupport;
  Edge edge;

  private static final Logger log = Logger.getLogger(ElementIteratorGVS.class.getName());
  
  public ElementIteratorGVS(PositionList<E> L, GvsSupport gvsSupport) {
    super(L);
    this.gvsSupport = gvsSupport;
  }
  
  @Override
  public E next() throws NoSuchElementException {
    E e = super.next();
    edge = (Edge)e;
    log.fine(edge.toString());
    gvsSupport.setTestingStart(edge);
    return e;
  }
  
  
  @Override
  public boolean hasNext() {
    if (edge != null) {
      gvsSupport.setTestingEnd();
      edge = null;
    }
    boolean result = super.hasNext();
    return result;
  }
  
}
