package ch.hsr.prog2.dijkstragvs;

import java.util.logging.Logger;

import ch.hsr.prog2.dijkstragvs.AdjacencyListGraphGVS.MyGvsVertex;
import net.datastructures.EmptyPriorityQueueException;
import net.datastructures.Entry;
import net.datastructures.HeapAdaptablePriorityQueue;
import net.datastructures.InvalidEntryException;
import net.datastructures.InvalidKeyException;

@SuppressWarnings({"unchecked"})

public class HeapAdaptablePriorityQueueGVS<K,V> extends HeapAdaptablePriorityQueue<K,V> {
  
  protected GvsSupport gvsSupport;
  
  private static final Logger log = Logger.getLogger(HeapAdaptablePriorityQueueGVS.class.getName());
 
  @Override
  public Entry<K,V> insert(K k, V v) throws InvalidKeyException {
    Entry<K,V> entry = super.insert(k, v);
    log.fine(entry.toString());
    log.finest(toString());
    return entry;
  }
  
  @Override
  public Entry<K,V> removeMin() throws EmptyPriorityQueueException {
    Entry<K,V> entry = super.removeMin();
    MyGvsVertex vertex = (MyGvsVertex)entry.getValue();
    log.fine(entry.toString());
    log.finest(toString());
    gvsSupport.newVertexInCloud(vertex);
    return entry;
  }

  @Override
  public K replaceKey(Entry<K,V> entry, K newKey) throws InvalidEntryException {
    String oldEntry = entry.toString();
    K oldKey = super.replaceKey(entry, newKey);
    log.fine(oldEntry+" -> "+entry.toString());
    log.finest(toString());
    return oldKey;
  }
  
}
