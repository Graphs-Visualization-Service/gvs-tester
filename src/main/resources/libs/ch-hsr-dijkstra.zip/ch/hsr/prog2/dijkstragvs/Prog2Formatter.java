package ch.hsr.prog2.dijkstragvs;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

public class Prog2Formatter extends SimpleFormatter {
  
  private StringBuffer mBuffer = new StringBuffer();
  
  @Override
  public String format(LogRecord pRecord) {
    mBuffer.setLength(0);
    Level level = pRecord.getLevel();
    String levelStr = null;
    if (level == Level.OFF) {
      levelStr = "OFF";
    }
    else if (level == Level.SEVERE) {
      levelStr = "SEV";
    }
    else if (level == Level.WARNING) {
      levelStr = "WRN";
    }
    else if (level == Level.INFO) {
      levelStr = "INF";
    }
    else if (level == Level.FINE) {
      levelStr = "FIN";
    }
    else if (level == Level.FINER) {
      levelStr = "FNR";
    }
    else if (level == Level.FINEST) {
      levelStr = "FNT";
    }
    //mBuffer.append(levelStr);
    //mBuffer.append(": ");
    String className = pRecord.getSourceClassName();
    char separator = 0;
    if (className.indexOf('$') != -1) {
      separator = '$';
    } else {
      separator = '.';
    }
    mBuffer.append(className.substring(className.lastIndexOf(separator)+1));
    mBuffer.append(".");
    mBuffer.append(pRecord.getSourceMethodName());
    mBuffer.append("(): ");
    mBuffer.append(pRecord.getMessage());
    mBuffer.append('\n');
    return mBuffer.toString();
  }
  
}
